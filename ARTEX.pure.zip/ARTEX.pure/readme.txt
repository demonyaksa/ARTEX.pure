此版本已通过安全审计，移除了自更新功能，仅本地编译使用。
工具依赖安装脚本：install_artex_tools.sh


2016-11-20 modified by bemo