#!/usr/bin/env bash
set -euo pipefail

echo "=== ARTEX 本地工具依赖安装脚本 ==="
echo "说明：只安装 ARTEX worker 可能用到的外部工具，不编译 ARTEX，不安装 PostgreSQL。"

# 检测发行版
if [ -f /etc/os-release ]; then
  . /etc/os-release
  DISTRO="${ID:-}"
else
  echo "无法识别发行版，请手动安装依赖。"
  exit 1
fi

install_apt() {
  sudo apt-get update
  sudo apt-get install -y \
    curl \
    nmap \
    ripgrep \
    nodejs \
    npm \
    python3 \
    python3-pip \
    python3-venv \
    git \
    ca-certificates
}

install_dnf() {
  sudo dnf install -y \
    curl \
    nmap \
    ripgrep \
    nodejs \
    npm \
    python3 \
    python3-pip \
    python3-venv \
    git \
    ca-certificates
}

install_yum() {
  sudo yum install -y \
    curl \
    nmap \
    ripgrep \
    nodejs \
    npm \
    python3 \
    python3-pip \
    git \
    ca-certificates
}

install_pacman() {
  sudo pacman -Sy --noconfirm \
    curl \
    nmap \
    ripgrep \
    nodejs \
    npm \
    python \
    python-pip \
    python-virtualenv \
    git \
    ca-certificates
}

install_zypper() {
  sudo zypper install -y \
    curl \
    nmap \
    ripgrep \
    nodejs \
    npm \
    python3 \
    python3-pip \
    git \
    ca-certificates
}

case "$DISTRO" in
  ubuntu|debian|kali)
    install_apt
    ;;
  fedora|rhel|centos|rocky|almalinux)
    if command -v dnf >/dev/null 2>&1; then
      install_dnf
    else
      install_yum
    fi
    ;;
  arch|manjaro)
    install_pacman
    ;;
  opensuse*|suse)
    install_zypper
    ;;
  *)
    echo "未适配的发行版: $DISTRO"
    echo "请手动安装：bash curl nmap ripgrep node npm python3 pip git"
    exit 1
    ;;
esac

# 安装 Playwright Python 包
if command -v python3 >/dev/null 2>&1; then
  echo "正在安装 playwright Python 包..."
  python3 -m pip install --user --break-system-packages playwright 2>/dev/null \

    || python3 -m pip install --user playwright
fi

# 安装 Chromium 浏览器
if command -v python3 >/dev/null 2>&1 && python3 -m playwright --version >/dev/null 2>&1; then
  echo "正在安装 Playwright Chromium 浏览器..."
  python3 -m playwright install chromium
else
  echo "Playwright 未正确安装，可稍后手动执行："
  echo "  python3 -m pip install playwright"
  echo "  python3 -m playwright install chromium"
fi

echo ""
echo "=== 工具检查 ==="
for cmd in bash curl nmap rg node npm python3 playwright; do
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "OK: $cmd -> $(command -v "$cmd")"
  else
    echo "MISSING: $cmd"
  fi
done

echo ""
echo "完成。如果某项显示 MISSING，说明该工具仍未安装成功。"